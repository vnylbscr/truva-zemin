const primary = '#464660';
const secondary = '#f1e9e5';

export default {
   primary,
   secondary,
};
