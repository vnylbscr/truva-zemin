exports.id = 201;
exports.ids = [201];
exports.modules = {

/***/ 3372:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ appBar; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "semantic-ui-react"
var external_semantic_ui_react_ = __webpack_require__(1347);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(9914);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./node_modules/next/dist/client/router.js
var client_router = __webpack_require__(4651);
;// CONCATENATED MODULE: ./data/appbarItems.js
const HEADER_DATA = [{
  label: 'Anasayfa',
  url: '/',
  value: 'home',
  icon: 'home'
}, {
  label: 'Hakkımızda',
  url: '/about',
  value: 'about',
  icon: 'info'
}, {
  label: 'Ekipmanlarımız',
  url: '/equipments',
  value: 'equipments',
  icon: 'american sign language interpreting'
}, {
  label: 'Galeri',
  url: '/gallery',
  value: 'gallery',
  icon: 'envira gallery'
}, {
  label: 'Referanslarımız',
  url: '/references',
  value: 'references',
  icon: 'tty'
}, {
  label: 'İletişim',
  url: '/contact',
  value: 'contact',
  icon: 'fax'
}, {
  label: 'Blog',
  url: '/blog',
  value: 'blog',
  icon: 'blogger b'
}];
;// CONCATENATED MODULE: ./components/sidebar.js






const MySideBar = ({
  backgroundColor,
  visible,
  onClose,
  handleClickMenuItem
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid, {
      columns: visible && 1,
      children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid.Column, {
        children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Sidebar, {
          as: external_semantic_ui_react_.Menu,
          animation: "overlay",
          icon: "labeled",
          inverted: true,
          onHide: onClose,
          vertical: true,
          visible: visible,
          width: "thin",
          children: HEADER_DATA.map(item => /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Menu.Item, {
            onClick: () => handleClickMenuItem(item.url),
            as: "a",
            children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Icon, {
              name: item.icon
            }), item.label]
          }, item.value))
        })
      })
    })
  });
};

/* harmony default export */ var sidebar = (MySideBar);
// EXTERNAL MODULE: ./hooks/useResponsiveScreen.js
var useResponsiveScreen = __webpack_require__(5572);
// EXTERNAL MODULE: ./components/icons/index.js
var icons = __webpack_require__(5117);
;// CONCATENATED MODULE: ./components/appBar.js










const StyledNavTitle = (external_styled_components_default()).p`
   font-size: 16px;
   /* border: 1px solid rebeccapurple; */
`;

const AppBar = props => {
  const {
    0: openSidebar,
    1: setOpenSidebar
  } = (0,external_react_.useState)(false);
  const router = (0,client_router.useRouter)();
  const {
    isSmallScreen,
    isMediumScreen
  } = (0,useResponsiveScreen/* default */.Z)();

  const handleClick = url => {
    router.push(url);
  };

  const handleClickMenu = () => setOpenSidebar(!openSidebar);

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid, {
      divided: "vertically",
      stackable: true,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Grid.Row, {
        columns: 2,
        style: {
          marginTop: 20
        },
        divided: true,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Grid.Column, {
          largeScreen: 4,
          mobile: 16,
          textAlign: "center",
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Image, {
            onClick: () => router.push('/'),
            alt: "truva-zemin ara\u015Ft\u0131rmalar\u0131",
            className: "logo",
            src: "/media/truva_appbar.jpg",
            centered: true
          }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid, {
            verticalAlign: "middle",
            columns: 1,
            children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid.Column, {
              only: "mobile",
              floated: "left",
              children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Button, {
                fluid: true,
                size: "medium",
                onClick: handleClickMenu,
                icon: true,
                style: {
                  margin: '20px 0'
                },
                children: /*#__PURE__*/jsx_runtime_.jsx(icons/* MenuIcon */.Oq, {})
              })
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(sidebar, {
          visible: openSidebar,
          handleClickMenuItem: handleClick,
          onClose: handleClickMenu
        }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid.Column, {
          className: "appBar",
          only: "computer and tablet",
          width: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Menu, {
            secondary: true,
            pointing: true,
            children: HEADER_DATA.map(item => /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Menu.Item, {
              active: item.url === router.pathname,
              onClick: () => handleClick(item.url),
              children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid, {
                className: "menuItem",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Grid.Row, {
                  columns: 2,
                  verticalAlign: "middle",
                  children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid.Column, {
                    width: 3,
                    children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Icon, {
                      name: item.icon,
                      size: "large"
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid.Column, {
                    width: 12,
                    children: /*#__PURE__*/jsx_runtime_.jsx(StyledNavTitle, {
                      children: item.label
                    })
                  })]
                })
              })
            }, item.value))
          })
        })]
      })
    })
  });
};

/* harmony default export */ var appBar = (AppBar);

/***/ }),

/***/ 3561:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ footer; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./node_modules/next/dist/client/router.js
var client_router = __webpack_require__(4651);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "semantic-ui-react"
var external_semantic_ui_react_ = __webpack_require__(1347);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(9914);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./components/testComponent.js



const TestComponent = () => {
  return /*#__PURE__*/_jsx("h1", {
    children: "Selam mert"
  });
};

/* harmony default export */ var testComponent = ((/* unused pure expression or super */ null && (TestComponent)));
;// CONCATENATED MODULE: ./components/footer.js







const StyledSpan = (external_styled_components_default()).a`
   color: #fff;
   transition: all 0.7s;
   margin-left: 5px;
   :hover {
      color: limegreen;
      cursor: pointer;
      text-decoration: underline;
   }
`;
const StyledIcon = external_styled_components_default()(external_semantic_ui_react_.Icon)`
   color: aliceblue;
   transition: all 1s;
   :hover {
      color: grey;
      cursor: pointer;
      transform: translateY(-2px);
   }
`;
const FOOTER_SOCIAL_MEDIAS = [{
  url: 'https://linkedin.com/in/muhammet-gen%C3%A7-8003a092/?originalSubdomain=tr',
  name: 'linkedin'
}, {
  url: 'https://instagram.com/mhmmtgncc/?hl=tr',
  name: 'instagram'
}, {
  url: 'https://wa.me/+905549900997',
  name: 'whatsapp'
}];

const Footer = () => {
  const router = (0,client_router.useRouter)();
  return /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Segment, {
    inverted: true,
    vertical: true,
    style: {
      padding: '5em 0em'
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Container, {
      textAlign: "center",
      children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Grid, {
        divided: true,
        inverted: true,
        stackable: true,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Grid.Column, {
          width: 16,
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Header, {
            inverted: true,
            as: "h3",
            content: "Truva Zemin & Et\xFCt Ara\u015Ft\u0131rmalar\u0131 LTD \u015ET\u0130"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
            children: ["Copyright \xA9 ", new Date().getFullYear(), /*#__PURE__*/(0,jsx_runtime_.jsxs)(StyledSpan, {
              target: "_blank",
              rel: "noopener noreferrer",
              href: "https://www.linkedin.com/in/mert-gen%C3%A7-17b93212a/",
              children: ["Mert Gen\xE7 ", '\n', ' ']
            }), "Build with", /*#__PURE__*/jsx_runtime_.jsx(StyledSpan, {
              target: "_blank",
              rel: "noopener noreferrer",
              href: "https://nextjs.org",
              children: "Next.js"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            children: "All Rights Reserved."
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Divider, {
        inverted: true,
        section: true
      }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Image, {
        centered: true,
        size: "medium",
        src: "/media/truva_appbar.jpg",
        alt: "truva_logo"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.List, {
        horizontal: true,
        inverted: true,
        divided: true,
        link: true,
        size: "small",
        children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.List.Item, {
          as: "a",
          children: "Site Haritas\u0131"
        }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.List.Item, {
          as: "a",
          onClick: () => router.push('/contact'),
          children: "Bize Ula\u015F\u0131n"
        }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.List.Item, {
          as: "a",
          children: "Gizlilik Politikas\u0131"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Divider, {}), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.List, {
        horizontal: true,
        children: FOOTER_SOCIAL_MEDIAS.map((item, index) => {
          return /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.ListItem, {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: item.url,
              target: "_blank",
              rel: "noopener noreferrer",
              children: /*#__PURE__*/jsx_runtime_.jsx(StyledIcon, {
                name: item.name,
                size: "big"
              })
            })
          }, item.url + index);
        })
      })]
    })
  });
};

/* harmony default export */ var footer = (Footer);

/***/ }),

/***/ 5117:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Oq": function() { return /* binding */ MenuIcon; },
/* harmony export */   "Y4": function() { return /* binding */ ArrowLeftIcon; },
/* harmony export */   "LZ": function() { return /* binding */ ArrowRightIcon; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const MenuIcon = ({
  className,
  fill
}) => {
  const iconClassName = className ? className : 'myIcon';
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    className: iconClassName,
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor",
    style: {
      width: 35,
      height: 35
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: 2,
      d: "M4 6h16M4 12h16M4 18h16"
    })
  });
};
const ArrowLeftIcon = ({
  className,
  fill
}) => {
  const iconClassName = className ? className : 'myIcon';
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    className: iconClassName // fill='none'
    ,
    viewBox: "0 0 24 24",
    stroke: "currentColor",
    style: {
      width: 25,
      height: 25
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: 2,
      d: "M9 5l7 7-7 7"
    })
  });
};
const ArrowRightIcon = ({
  className,
  fill
}) => {
  const iconClassName = className ? className : 'myIcon';
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    className: iconClassName // fill='none'
    ,
    viewBox: "0 0 24 24",
    stroke: "currentColor",
    style: {
      width: 25,
      height: 25
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: 2,
      d: "M9 5l7 7-7 7"
    })
  });
};

/***/ }),

/***/ 5572:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8098);
/* harmony import */ var _useWindowSize__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1470);




const useResponsiveScreen = () => {
  const {
    width
  } = (0,_useWindowSize__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)();
  const [isSmallScreen, setSmallScreen] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  const [isMediumScreen, setMediumScreen] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    if (width < _lib_constants__WEBPACK_IMPORTED_MODULE_2__/* .SMALL_SCREEN_SIZE */ .qo) {
      setSmallScreen(true);
      setMediumScreen(false);
    } else if (_lib_constants__WEBPACK_IMPORTED_MODULE_2__/* .SMALL_SCREEN_SIZE */ .qo < width < _lib_constants__WEBPACK_IMPORTED_MODULE_2__/* .MEDIUM_SCREEN_SIZE */ .xn) {
      setMediumScreen(true);
      setSmallScreen(false);
    } else {
      setSmallScreen(false);
      setMediumScreen(false);
    }
  }, [width]);
  return {
    isSmallScreen,
    isMediumScreen
  };
};

/* harmony default export */ __webpack_exports__["Z"] = (useResponsiveScreen);

/***/ }),

/***/ 1470:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ hooks_useWindowSize; }
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./lib/isServer.js
const isServer = true;
;// CONCATENATED MODULE: ./hooks/useWindowSize.js



const useWindowSize = () => {
  const {
    0: windowSize,
    1: setWindowSize
  } = (0,external_react_.useState)({
    width: undefined,
    height: undefined
  });
  (0,external_react_.useEffect)(() => {
    if (!isServer) {
      const handleResize = () => {
        setWindowSize({
          width: window.innerWidth,
          height: window.innerHeight
        });
      };

      window.addEventListener('resize', handleResize);
      handleResize();
      return () => window.removeEventListener('resize', handleResize);
    }
  }, []);
  return windowSize;
};

/* harmony default export */ var hooks_useWindowSize = (useWindowSize);

/***/ }),

/***/ 8098:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M9": function() { return /* binding */ SITE_HEAD_TITLE; },
/* harmony export */   "qo": function() { return /* binding */ SMALL_SCREEN_SIZE; },
/* harmony export */   "xn": function() { return /* binding */ MEDIUM_SCREEN_SIZE; }
/* harmony export */ });
/* unused harmony export SITE_NAME */
const SITE_NAME = 'TRUVA_ZEMIN';
const SITE_HEAD_TITLE = 'Truva Zemin & Sondaj & Jeolojik - Jeoteknik Etüt Araştırmaları';
const SMALL_SCREEN_SIZE = 625;
const MEDIUM_SCREEN_SIZE = 1025;

/***/ }),

/***/ 4453:
/***/ (function() {

/* (ignored) */

/***/ })

};
;