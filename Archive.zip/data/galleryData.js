export const GALLERY_DATA = [
   {
      image: '/media/media01.png',
      headerTitle: 'Sancaktepe/İstanbul',
      description: 'Şirketimiz tarafından yapılan bazı çalışmalar',
      cardMeta: 'Mart 2017',
   },
   {
      image: '/media/media02.jpeg',
      headerTitle: 'Sancaktepe/İstanbul',
      description: 'Şirketimiz tarafından yapılan bazı çalışmalar',
      cardMeta: 'Şubat 2018',
   },
   {
      image: '/media/media03.jpeg',
      headerTitle: 'Sancaktepe/İstanbul',
      description: 'Şirketimiz tarafından yapılan bazı çalışmalar',
      cardMeta: 'Mayıs 2019',
   },
   {
      image: '/media/media04.jpeg',
      headerTitle: 'Sancaktepe/İstanbul',
      description: 'Şirketimiz tarafından yapılan bazı çalışmalar',
      cardMeta: '22.06.2017',
   },
   {
      image: '/media/media05.png',
      headerTitle: 'Sancaktepe/İstanbul',
      description: 'Şirketimiz tarafından yapılan bazı çalışmalar',
      cardMeta: '20 Haziran 2021',
   },
];
