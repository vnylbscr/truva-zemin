import React from 'react';

const TestComponent = () => {
   return <h1>Selam mert</h1>;
};

export default TestComponent;
